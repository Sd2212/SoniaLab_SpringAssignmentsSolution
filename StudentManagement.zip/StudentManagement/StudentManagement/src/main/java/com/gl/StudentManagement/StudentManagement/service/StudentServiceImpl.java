package com.gl.StudentManagement.StudentManagement.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.gl.StudentManagement.StudentManagement.repository.StudentRepository;

import com.gl.StudentManagement.StudentManagement.entity.Student;

@Repository
public class StudentServiceImpl implements StudentService {

	@Autowired
	StudentRepository studentRepository;

	@Transactional
	public List<Student> findAll() {

		List<Student> students = studentRepository.findAll();
		return students;
	}

	@Transactional
	public Student findById(int theId) {

		return studentRepository.findById(theId).get();

	}

	@Transactional
	public void save(Student theStudent) {

		studentRepository.save(theStudent);

	}

	@Transactional
	public void deleteById(int theId) {

		studentRepository.deleteById(theId);

	}

	@Transactional
	public void print(List<Student> student) {

		for (Student s : student) {
			System.out.println(s);
		}
	}

}
