package com.gl.StudentManagement.StudentManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gl.StudentManagement.StudentManagement.entity.Student;
import com.gl.StudentManagement.StudentManagement.service.StudentService;


@Controller
@RequestMapping("/student")

public class StudentController {

	@Autowired
	private StudentService stdService;

	@RequestMapping("/list")
	public String listStudents(Model theModel) {

		List<Student> theStudents = stdService.findAll();

		theModel.addAttribute("Students", theStudents);

		return "StudentList";
	}

	@RequestMapping("/add")
	public String addStudents(Model theModel) {

		Student theStudent = new Student();

		theModel.addAttribute("Student", theStudent);

		return "StudentForm";
	}

	@RequestMapping("/update")
	public String showFormForUpdate(@RequestParam("stdId") int id, Model theModel) {

		Student theStudent = stdService.findById(id);

		theModel.addAttribute("Student", theStudent);

		return "StudentForm";
	}

	@PostMapping("/save")
	public String saveBook(@RequestParam("id") int id, @RequestParam("name") String name,
			@RequestParam("course") String course, @RequestParam("country") String country) {

		System.out.println(id);
		Student theStudent;
		if (id!=0) {
			theStudent = stdService.findById(id);
			theStudent.setId(id);
			theStudent.setName(name);
			theStudent.setCourse(course);
			theStudent.setCountry(country);
		} else
			theStudent = new Student(id, name, course, country);

		stdService.save(theStudent);

		return "redirect:/student/list";

	}

	@RequestMapping("/delete")
	public String delete(@RequestParam("stdId") int id) {

		stdService.deleteById(id);

		return "redirect:/student/list";

	}

}
